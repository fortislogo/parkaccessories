<?php
################################################################################################
#  DIY Module Builder for Opencart 1.5.0.x From HostJars http://opencart.hostjars.com    	   #
################################################################################################

// Heading 
$_['heading_title']  = 'Beauty Shop Theme Admin';

// Text
//Add any you need here, the same way described in the admin section.
?>